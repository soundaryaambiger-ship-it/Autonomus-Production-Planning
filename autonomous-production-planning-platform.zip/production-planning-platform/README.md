# Autonomous Production Planning Platform

A full-stack starter based on the supplied architecture: React + TypeScript + Vite frontend, FastAPI backend, Google ADK / Vertex AI integration, manufacturing demo data, deterministic planning services, scenario simulation, and plan approval workflow.

> This is a runnable starter, not a certified factory control system. Demo records are simulated. ERP/MES/WMS/HRIS/CMMS connectors and production-grade scheduling optimization must be implemented and validated against your systems before operational use.

## Architecture
- **Frontend**: React, TypeScript, Vite, Recharts, Lucide icons.
- **Backend**: FastAPI, Pydantic, deterministic planning services.
- **AI**: Google ADK agent with Vertex AI configuration; optional graceful fallback when credentials/dependencies are not configured.
- **Data**: In-memory demo data. Replace with BigQuery/database and enterprise connectors for production.

## Requirements
- Python 3.11+
- Node.js 20+
- Google Cloud project with Vertex AI API enabled if using the AI copilot
- Google Cloud credentials (Application Default Credentials recommended)

## 1. Configure environment
Copy `backend/.env.example` to `backend/.env` and fill in your values. Do not commit `.env` or share credentials.

```env
GOOGLE_GENAI_USE_VERTEXAI=true
GOOGLE_CLOUD_PROJECT=your-gcp-project-id
GOOGLE_CLOUD_LOCATION=us-central1
GOOGLE_APPLICATION_CREDENTIALS=/absolute/path/to/service-account.json
VERTEX_AI_MODEL=gemini-2.5-flash
```

Prefer `gcloud auth application-default login` for local development where possible. If using a service-account key, keep it outside the repository and never paste its contents into chat or source control. Grant least-privilege Vertex AI permissions.

## 2. Start backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # Windows: copy .env.example .env
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```
API docs: http://127.0.0.1:8000/docs

## 3. Start frontend
In another terminal:
```bash
cd frontend
npm install
npm run dev
```
Open the local URL printed by Vite (usually http://localhost:5173).

## Useful endpoints
- `GET /api/health`
- `GET /api/dashboard`
- `GET /api/orders`
- `GET /api/schedule`
- `POST /api/simulate` body: `{"scenario":"machine_failure","machine_id":"M1","demand_increase_pct":0}`
- `POST /api/plan/generate`
- `POST /api/plan/{plan_id}/approve` body: `{"approved_by":"Plant Manager","comment":"Reviewed"}`
- `POST /api/copilot/chat` body: `{"message":"Which orders are at risk?"}`

## What is implemented
- Polished responsive planning dashboard and sidebar navigation.
- KPI cards, production schedule timeline, order table, exception panel.
- Scenario simulator with deterministic impact summary.
- Rule-based schedule generator and approval workflow (demo/in-memory).
- ADK agent configuration that calls Vertex AI when configured; a useful fallback response is returned if ADK is not available.

## Before production use
1. Replace in-memory state with a durable database and migrations.
2. Integrate ERP, MES, WMS, HRIS, and CMMS using authenticated APIs.
3. Implement real finite-capacity scheduling with constraints, setup times, calendars, and due-date objectives; validate with operations experts.
4. Add identity provider authentication, role-based authorization, audit logs, secrets management, rate limits, and tests.
5. Require explicit human approval before writing to ERP/MES. Keep a rollback/versioning strategy.
6. Validate AI output; never let an LLM alone calculate safety-critical or authoritative schedule quantities.
