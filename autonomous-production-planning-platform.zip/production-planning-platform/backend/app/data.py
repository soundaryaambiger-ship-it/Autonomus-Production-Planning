from datetime import datetime, timedelta
from uuid import uuid4

ORDERS = [
    {"id":"ORD-1041","product":"Control Module A","quantity":500,"priority":"High","due":"Today, 16:00","status":"At risk","material_ready":True},
    {"id":"ORD-1042","product":"Sensor Board B","quantity":320,"priority":"Medium","due":"Tomorrow, 12:00","status":"Scheduled","material_ready":True},
    {"id":"ORD-1043","product":"Power Unit C","quantity":180,"priority":"High","due":"Tomorrow, 17:00","status":"Material hold","material_ready":False},
    {"id":"ORD-1044","product":"Gateway Module D","quantity":240,"priority":"Low","due":"Oct 28, 14:00","status":"Scheduled","material_ready":True},
]
MACHINES = [
    {"id":"M1","name":"Assembly Line 01","utilization":86,"status":"Running","capacity_hours":8},
    {"id":"M2","name":"SMT Line 02","utilization":72,"status":"Running","capacity_hours":8},
    {"id":"M3","name":"Testing Cell 03","utilization":48,"status":"Maintenance window","capacity_hours":6},
]
SCHEDULE = [
    {"id":"T-01","order_id":"ORD-1041","task":"Control Module A · Assembly","machine":"M1","start":"08:00","end":"10:30","progress":68,"color":"blue"},
    {"id":"T-02","order_id":"ORD-1042","task":"Sensor Board B · SMT","machine":"M2","start":"08:30","end":"11:00","progress":42,"color":"violet"},
    {"id":"T-03","order_id":"ORD-1041","task":"Control Module A · Testing","machine":"M3","start":"10:45","end":"12:00","progress":0,"color":"amber"},
    {"id":"T-04","order_id":"ORD-1043","task":"Power Unit C · Assembly","machine":"M1","start":"11:00","end":"13:30","progress":0,"color":"rose"},
    {"id":"T-05","order_id":"ORD-1044","task":"Gateway Module D · Assembly","machine":"M2","start":"12:00","end":"14:00","progress":0,"color":"emerald"},
]
PLANS = {}
EXCEPTIONS = [
    {"id":"EX-208","severity":"high","title":"Order ORD-1041 at risk","detail":"Testing window is tight against today's dispatch cutoff.","time":"8 min ago"},
    {"id":"EX-211","severity":"medium","title":"Power Unit C material hold","detail":"Connector stock is below the required quantity.","time":"22 min ago"},
    {"id":"EX-214","severity":"low","title":"Testing Cell 03 maintenance","detail":"Planned maintenance reduces available capacity by 2 hours.","time":"1 hr ago"},
]

def dashboard():
    return {"kpis":[
        {"label":"Active orders","value":"24","change":"+8.2%","trend":"up","note":"vs. last shift"},
        {"label":"On-time delivery","value":"94.8%","change":"+2.4%","trend":"up","note":"vs. last week"},
        {"label":"Machine utilization","value":"78.6%","change":"-1.1%","trend":"down","note":"vs. last shift"},
        {"label":"Open exceptions","value":str(len(EXCEPTIONS)),"change":"2 urgent","trend":"alert","note":"needs attention"}
    ],"machines":MACHINES,"exceptions":EXCEPTIONS,"orders":ORDERS,"schedule":SCHEDULE,"source":"Simulated demo data"}
