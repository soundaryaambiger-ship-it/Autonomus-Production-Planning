"""Google ADK agent wrapper. Uses Vertex AI through environment configuration."""
from app.config import settings

SYSTEM_INSTRUCTION = """You are a manufacturing production-planning copilot. Use only the provided context for plant facts. Clearly distinguish known data from assumptions. Do not claim to have changed ERP/MES data. Explain trade-offs, call out missing constraints, and require human approval before a plan is published. For exact capacity or material calculations, defer to deterministic planning services."""

async def ask_planning_agent(message: str, context: dict) -> dict:
    try:
        from google.adk.agents import Agent
        from google.adk.runners import Runner
        from google.adk.sessions import InMemorySessionService
        from google.genai import types
        if not settings.google_cloud_project:
            raise RuntimeError("GOOGLE_CLOUD_PROJECT is not configured")
        agent = Agent(
            name="production_planning_copilot",
            model=settings.vertex_ai_model,
            instruction=SYSTEM_INSTRUCTION,
            description="Answers manufacturing planning questions using current dashboard context.",
        )
        session_service = InMemorySessionService()
        app_name, user_id, session_id = "production_planning", "dashboard_user", "planning_session"
        await session_service.create_session(app_name=app_name, user_id=user_id, session_id=session_id)
        runner = Runner(agent=agent, app_name=app_name, session_service=session_service)
        prompt = f"Manufacturing context (simulated demo data unless explicitly stated): {context}\nUser question: {message}"
        content = types.Content(role="user", parts=[types.Part(text=prompt)])
        answer_parts = []
        async for event in runner.run_async(user_id=user_id, session_id=session_id, new_message=content):
            if getattr(event, "is_final_response", lambda: False)():
                for part in getattr(getattr(event, "content", None), "parts", []) or []:
                    if getattr(part, "text", None): answer_parts.append(part.text)
        if answer_parts:
            return {"answer":"\n".join(answer_parts),"mode":"vertex_ai_adk"}
        return {"answer":"I could not obtain a final response from the configured model. Check Vertex AI permissions and backend logs.","mode":"vertex_ai_adk"}
    except Exception as exc:
        # Don't expose secrets or full provider errors to the browser.
        low = message.lower()
        if "risk" in low or "delay" in low:
            answer = "Demo analysis: ORD-1041 is marked at risk because its testing window is tight, and ORD-1043 is on material hold. Confirm the latest shop-floor and material data before changing the schedule."
        elif "machine" in low or "failure" in low:
            answer = "If a machine fails, identify tasks assigned to it, check alternate-machine capability and remaining capacity, then simulate the reassignment. Keep the change in draft until an authorized planner or manager approves it."
        else:
            answer = "The copilot fallback is active. Configure GOOGLE_CLOUD_PROJECT, Vertex AI access, and Google ADK dependencies to enable model responses. I can still provide guidance, but this response is not based on a live plant system."
        return {"answer":answer,"mode":"fallback","setup_hint":"Verify backend .env, Application Default Credentials, Vertex AI API, IAM permissions, and model availability."}
