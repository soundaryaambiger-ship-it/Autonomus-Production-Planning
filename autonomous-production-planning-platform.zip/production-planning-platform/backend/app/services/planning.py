from uuid import uuid4
from datetime import datetime
from app.data import ORDERS, MACHINES, SCHEDULE, PLANS

def generate_plan():
    # Transparent baseline heuristic; replace with a validated finite-capacity optimizer.
    ordered = sorted(ORDERS, key=lambda x: (x["priority"] != "High", not x.get("material_ready", True), x["due"]))
    tasks = []
    slots = {m["id"]: 8 * 60 for m in MACHINES}
    for idx, order in enumerate(ordered):
        if not order.get("material_ready", True):
            continue
        machine = "M1" if idx % 2 == 0 else "M2"
        duration = max(30, min(180, round(order["quantity"] / 3)))
        start_min = (8 * 60) + (8 * 60 - slots[machine])
        end_min = start_min + duration
        slots[machine] = max(0, slots[machine] - duration)
        tasks.append({"id":f"GEN-{idx+1}","order_id":order["id"],"task":f"{order['product']} · Production","machine":machine,"start":f"{start_min//60:02d}:{start_min%60:02d}","end":f"{end_min//60:02d}:{end_min%60:02d}","progress":0,"color":["blue","violet","emerald","amber"][idx%4]})
    plan_id = f"PLAN-{uuid4().hex[:6].upper()}"
    plan = {"id":plan_id,"status":"Pending approval","created_at":datetime.now().isoformat(timespec="seconds"),"tasks":tasks,"notes":"Generated using a transparent baseline heuristic. Verify constraints before operational use."}
    PLANS[plan_id] = plan
    return plan

def simulate(scenario: str, machine_id: str = "M1", demand_increase_pct: float = 0):
    impacted = [t for t in SCHEDULE if scenario == "machine_failure" and t["machine"] == machine_id]
    if scenario == "demand_increase":
        impacted = SCHEDULE[:]
        demand_increase_pct = max(0, min(200, demand_increase_pct))
        summary = f"A {demand_increase_pct:g}% demand increase may exceed current capacity. Prioritize high-priority orders and evaluate overtime or additional shifts."
    elif scenario == "material_delay":
        impacted = [t for t in SCHEDULE if t["order_id"] == "ORD-1043"]
        summary = "Power Unit C tasks are exposed to a material delay. Confirm supplier ETA and resequence ready orders while material is unavailable."
    else:
        summary = f"Machine {machine_id} is unavailable. {len(impacted)} scheduled task(s) directly reference it; review reassignment to available capacity before publishing."
    return {"scenario":scenario,"machine_id":machine_id,"demand_increase_pct":demand_increase_pct,"impacted_tasks":impacted,"impact_count":len(impacted),"summary":summary,"recommendations":["Keep the approved plan unchanged until a planner reviews the scenario.","Check downstream testing and dispatch deadlines.","Recalculate capacity after confirming machine, material, and workforce availability."],"source":"Demo scenario analysis; not a live plant prediction"}
