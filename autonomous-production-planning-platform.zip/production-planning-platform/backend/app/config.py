from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_env: str = "development"
    cors_origins: str = "http://localhost:5173"
    google_cloud_project: str = ""
    google_cloud_location: str = "us-central1"
    vertex_ai_model: str = "gemini-2.5-flash"
    google_genai_use_vertexai: bool = True
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
