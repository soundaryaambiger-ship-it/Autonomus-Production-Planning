from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from app.config import settings
from app.data import dashboard, ORDERS, SCHEDULE, PLANS
from app.services.planning import generate_plan, simulate
from app.agents.planning_agent import ask_planning_agent

app = FastAPI(title="Autonomous Production Planning API", version="1.0.0", description="Demo API for AI-assisted manufacturing planning.")
origins = [x.strip() for x in settings.cors_origins.split(",") if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

class SimulationRequest(BaseModel):
    scenario: str = Field(pattern="^(machine_failure|demand_increase|material_delay)$")
    machine_id: str = "M1"
    demand_increase_pct: float = Field(default=0, ge=0, le=200)

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=4000)

class ApprovalRequest(BaseModel):
    approved_by: str = Field(min_length=2, max_length=120)
    comment: str = Field(default="", max_length=1000)

@app.get("/api/health")
def health():
    return {"status":"ok","service":"production-planning-api","environment":settings.app_env,"ai_project_configured":bool(settings.google_cloud_project)}

@app.get("/api/dashboard")
def get_dashboard(): return dashboard()

@app.get("/api/orders")
def get_orders(): return {"items":ORDERS,"total":len(ORDERS)}

@app.get("/api/schedule")
def get_schedule(): return {"items":SCHEDULE,"total":len(SCHEDULE)}

@app.post("/api/simulate")
def run_simulation(request: SimulationRequest):
    return simulate(request.scenario, request.machine_id, request.demand_increase_pct)

@app.post("/api/plan/generate")
def create_plan(): return generate_plan()

@app.get("/api/plan/{plan_id}")
def get_plan(plan_id: str):
    if plan_id not in PLANS: raise HTTPException(404, "Plan not found")
    return PLANS[plan_id]

@app.post("/api/plan/{plan_id}/approve")
def approve_plan(plan_id: str, request: ApprovalRequest):
    if plan_id not in PLANS: raise HTTPException(404, "Plan not found")
    plan = PLANS[plan_id]
    if plan["status"] != "Pending approval": raise HTTPException(409, "Only pending plans can be approved")
    plan["status"] = "Approved"
    plan["approved_by"] = request.approved_by
    plan["approval_comment"] = request.comment
    return plan

@app.post("/api/copilot/chat")
async def copilot_chat(request: ChatRequest):
    result = await ask_planning_agent(request.message, dashboard())
    return result
